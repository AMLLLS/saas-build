import { ReactNode } from 'react';

declare global {
  interface LayoutProps {
    children: ReactNode;
  }
} 
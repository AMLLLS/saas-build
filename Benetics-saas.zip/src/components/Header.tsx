import { motion } from 'framer-motion';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { navItemVariants, headerVariants } from '@/lib/animations';
import { cn } from '@/lib/utils';
import Logo from '@/assets/logos/logo.svg';

export function Header() {
  const pathname = usePathname();
  
  return (
    <motion.div 
      as="header"
      className="fixed w-full top-0 z-50 bg-white/80 backdrop-blur-sm"
      variants={headerVariants}
      initial="initial"
      animate="animate"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link href="/" className="flex-shrink-0">
            <Logo className="h-8 w-auto" />
          </Link>
          
          <nav className="flex items-center space-x-1">
            {[
              { name: 'Aperçu', href: '/apercu' },
              { name: 'Avantages', href: '/avantages' },
              { name: 'Tarifs', href: '/tarifs' },
              { name: 'Qui sommes-nous', href: '/about' },
              { name: 'Blog', href: '/blog' },
            ].map((item) => (
              <motion.div
                key={item.name}
                variants={navItemVariants}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Link
                  href={item.href}
                  className={cn(
                    'nav-item',
                    pathname === item.href && 'nav-item-active'
                  )}
                >
                  {item.name}
                </Link>
              </motion.div>
            ))}
          </nav>
          
          <div className="flex items-center space-x-4">
            <select className="bg-transparent border-none font-medium">
              <option value="fr">FR</option>
              <option value="en">EN</option>
            </select>
            
            <Link href="/login" className="font-medium text-gray-700 hover:text-gray-900">
              Connexion
            </Link>
            
            <Link
              href="/demo"
              className="bg-yellow-400 hover:bg-yellow-500 text-black px-6 py-2 rounded-full font-medium transition-colors"
            >
              Demander une démo
            </Link>
          </div>
        </div>
      </div>
    </motion.div>
  );
} 
import { FC } from 'react';
import AnimatedElement from '@/components/ui/AnimatedElement';
import FeatureCard from '@/components/ui/FeatureCard';

const features = [
  {
    title: "Rapports en temps réel",
    description: "Suivez l'avancement de vos projets en temps réel avec des rapports détaillés et personnalisables.",
    icon: "/images/icons/chart.svg"
  },
  {
    title: "Gestion des tâches",
    description: "Organisez et suivez toutes les tâches de vos chantiers de manière efficace et collaborative.",
    icon: "/images/icons/tasks.svg"
  },
  {
    title: "Archivage numérique",
    description: "Stockez et retrouvez facilement tous vos documents de chantier au même endroit.",
    icon: "/images/icons/folder.svg"
  },
  {
    title: "Communication intégrée",
    description: "Échangez avec votre équipe et vos clients directement depuis la plateforme.",
    icon: "/images/icons/chat.svg"
  }
];

const Features: FC = () => {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <AnimatedElement className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
            Pour vos projets de construction
          </h2>
          <p className="text-xl text-secondary-light">
            Des outils puissants pour optimiser la gestion de vos chantiers
          </p>
        </AnimatedElement>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <AnimatedElement 
              key={feature.title} 
              delay={index * 0.1}
              direction={index % 2 === 0 ? 'left' : 'right'}
            >
              <FeatureCard {...feature} />
            </AnimatedElement>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features; 
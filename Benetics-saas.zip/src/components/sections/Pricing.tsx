import { FC, useState } from 'react';
import { cn } from '@/lib/utils';

interface PricingPlan {
  name: string;
  price: string;
  description: string;
  buttonText: string;
  buttonLink: string;
}

const plans: PricingPlan[] = [
  {
    name: "Starter",
    price: "Gratuit",
    description: "Pour les petites équipes voulant plus de structure sur les chantiers et au bureau.",
    buttonText: "Commencer",
    buttonLink: "/register"
  },
  {
    name: "Pro",
    price: "17,- €",
    description: "Pour les entreprises de taille moyenne voulant dynamiser l'efficacité sur leurs multiples projets.",
    buttonText: "Commencer",
    buttonLink: "/register/pro"
  },
  {
    name: "Enterprise",
    price: "Individuel",
    description: "Pour les grandes entreprises gérant des projets de construction avec plusieurs acteurs.",
    buttonText: "Contacter",
    buttonLink: "/contact/enterprise"
  }
];

const PricingToggle: FC<{ isAnnual: boolean; onToggle: () => void }> = ({ isAnnual, onToggle }) => (
  <div className="inline-flex items-center bg-[#F3F3F3] rounded-full p-2 shadow-[0_2px_8px_rgba(0,0,0,0.08)] border border-gray-200">
    <button
      className={cn(
        "px-7 py-2.5 rounded-full text-[15px] font-medium transition-all",
        !isAnnual ? "bg-white shadow-sm text-gray-900 cursor-default" : "text-[#8A8A8A] hover:text-gray-900 cursor-pointer"
      )}
      onClick={() => isAnnual && onToggle()}
    >
      Mensuel
    </button>
    <button
      className={cn(
        "px-7 py-2.5 rounded-full text-[15px] font-medium transition-all flex items-center space-x-2",
        isAnnual ? "bg-white shadow-sm text-gray-900 cursor-default" : "text-[#8A8A8A] hover:text-gray-900 cursor-pointer"
      )}
      onClick={() => !isAnnual && onToggle()}
    >
      <span>Annuel</span>
      <span className="bg-[#FDB241] text-white text-xs px-1.5 py-0.5 rounded-full font-medium ml-1">-12%</span>
    </button>
  </div>
);

const PricingCard: FC<PricingPlan> = ({ name, price, description, buttonText, buttonLink }) => (
  <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-200/80">
    <h3 className="text-2xl font-bold text-gray-900 mb-2">{name}</h3>
    <div className="flex items-baseline mb-4">
      <span className="text-5xl font-bold text-gray-900">{price}</span>
      {price !== "Gratuit" && price !== "Individuel" && (
        <span className="ml-2 text-gray-500">par ut. / mois</span>
      )}
    </div>
    <p className="text-gray-500 mb-8">{description}</p>
    <a
      href={buttonLink}
      className="block w-full py-3.5 px-6 text-center rounded-full border border-gray-200 text-base font-medium hover:border-gray-300 transition-colors"
    >
      {buttonText}
    </a>
  </div>
);

const Pricing: FC = () => {
  const [isAnnual, setIsAnnual] = useState(false);

  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-white rounded-full px-4 py-1.5 shadow-[0_2px_8px_rgba(0,0,0,0.08)] mb-6">
            <span className="text-[#8A8A8A] text-sm font-bold">TARIFS</span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Ça vaut le coup pour vous et<br />
            votre équipe.
          </h2>
          
          <p className="text-xl text-gray-500 font-normal">
            Des tarifs simples et transparents. Essayez<br />
            Benetics gratuitement.
          </p>
        </div>

        <div className="text-center mb-12">
          <PricingToggle isAnnual={isAnnual} onToggle={() => setIsAnnual(!isAnnual)} />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.map((plan) => (
            <PricingCard key={plan.name} {...plan} />
          ))}
        </div>

        <div className="mt-16 text-center">
          <a 
            href="/pricing"
            className="inline-block py-4 px-8 bg-[#FDB241] rounded-full text-lg font-semibold text-white hover:bg-[#fca822] transition-colors"
          >
            En savoir plus
          </a>
        </div>
      </div>
    </section>
  );
};

export default Pricing; 
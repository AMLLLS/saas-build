import { FC } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Autoplay } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';

const testimonials: TestimonialProps[] = [
  {
    author: {
      name: "Jean Dupont",
      role: "Chef de projet",
      company: "Construction Pro",
      image: "/images/testimonials/user1.jpg"
    },
    content: "L'outil parfait pour gérer nos chantiers. Nous avons gagné un temps précieux dans la coordination de nos équipes."
  },
  {
    author: {
      name: "Marie Martin",
      role: "Directrice technique",
      company: "Bâtiment Plus",
      image: "/images/testimonials/user2.jpg"
    },
    content: "Une solution complète qui nous a permis d'améliorer significativement notre productivité sur les chantiers."
  },
  {
    author: {
      name: "Pierre Durand",
      role: "Conducteur de travaux",
      company: "Constructions Modernes",
      image: "/images/testimonials/user3.jpg"
    },
    content: "Interface intuitive et fonctionnalités puissantes. Je recommande vivement pour la gestion de projets de construction."
  }
];

const TestimonialCard: FC<TestimonialProps> = ({ author, content }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className="bg-white p-6 rounded-xl shadow-lg"
  >
    <div className="flex items-center mb-4">
      <div className="relative w-12 h-12 rounded-full overflow-hidden">
        <Image
          src={author.image}
          alt={author.name}
          fill
          className="object-cover"
        />
      </div>
      <div className="ml-4">
        <h4 className="font-semibold text-secondary">{author.name}</h4>
        <p className="text-sm text-secondary-light">
          {author.role} - {author.company}
        </p>
      </div>
    </div>
    <p className="text-secondary-light">{content}</p>
  </motion.div>
);

const Testimonials: FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
            L'avis de nos clients
          </h2>
          <p className="text-xl text-secondary-light">
            Découvrez ce que nos utilisateurs pensent de notre solution
          </p>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          <Swiper
            modules={[Pagination, Autoplay]}
            spaceBetween={30}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 5000 }}
            breakpoints={{
              640: {
                slidesPerView: 2,
              },
              1024: {
                slidesPerView: 3,
              },
            }}
            className="testimonials-swiper"
          >
            {testimonials.map((testimonial, index) => (
              <SwiperSlide key={index}>
                <TestimonialCard {...testimonial} />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </section>
  );
};

export default Testimonials; 
import { FC, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDownIcon } from '@heroicons/react/24/solid';

const faqs: FaqItem[] = [
  {
    question: "Comment puis-je commencer à utiliser la plateforme ?",
    answer: "Vous pouvez commencer en créant un compte gratuit. Une fois inscrit, vous aurez accès à toutes les fonctionnalités de base et pourrez upgrader votre compte à tout moment."
  },
  {
    question: "Quels types de projets puis-je gérer ?",
    answer: "Notre plateforme est adaptée à tous types de projets de construction : rénovation, construction neuve, travaux publics, etc. Vous pouvez personnaliser les outils selon vos besoins."
  },
  {
    question: "La plateforme est-elle accessible sur mobile ?",
    answer: "Oui, notre plateforme est entièrement responsive et accessible sur tous les appareils : ordinateurs, tablettes et smartphones. Une application mobile dédiée est également disponible."
  },
  {
    question: "Proposez-vous une formation pour utiliser l'outil ?",
    answer: "Oui, nous proposons des sessions de formation en ligne gratuites pour tous nos utilisateurs. Les clients Premium bénéficient également de formations personnalisées."
  },
  {
    question: "Comment fonctionne le support client ?",
    answer: "Notre équipe support est disponible par email 7j/7 pour tous les utilisateurs. Les clients Premium bénéficient d'un support prioritaire par téléphone et chat en direct."
  }
];

const FaqItem: FC<FaqItem & { isOpen: boolean; onClick: () => void }> = ({
  question,
  answer,
  isOpen,
  onClick
}) => (
  <motion.div
    initial={false}
    className="border-b border-gray-200 py-4"
  >
    <button
      className="flex justify-between items-center w-full text-left"
      onClick={onClick}
    >
      <span className="text-lg font-medium text-secondary">{question}</span>
      <motion.div
        animate={{ rotate: isOpen ? 180 : 0 }}
        transition={{ duration: 0.2 }}
      >
        <ChevronDownIcon className="w-5 h-5 text-primary" />
      </motion.div>
    </button>
    <AnimatePresence initial={false}>
      {isOpen && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="overflow-hidden"
        >
          <p className="pt-4 text-secondary-light">{answer}</p>
        </motion.div>
      )}
    </AnimatePresence>
  </motion.div>
);

const Faq: FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
            Questions fréquentes
          </h2>
          <p className="text-xl text-secondary-light">
            Tout ce que vous devez savoir sur notre plateforme
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <FaqItem
              key={index}
              {...faq}
              isOpen={openIndex === index}
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Faq; 